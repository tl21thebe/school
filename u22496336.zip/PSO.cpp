#include "PSO.h"
#include "Particle.h"
#include <fstream>
#include <sstream>

PSO::PSO(std::string fileName) {
    std::ifstream file(fileName.c_str());
    std::string line;
    numParticles = 0;
    // Count the number of particles (lines) in the file
    while (std::getline(file, line)) {
        if (!line.empty()) {
            numParticles++;
        }
    }
    // Allocate memory for particles array
    particles = new Particle*[numParticles];
    // Reset the file read position to the beginning
    file.clear();
    file.seekg(0, std::ios::beg);
    int index = 0;
    // Initialize each particle
    while (std::getline(file, line)) {
        if (!line.empty()) {
            particles[index++] = new Particle(line);
        }
    }
    file.close();
};
PSO::~PSO() {
    // Deallocate memory for each particle and the array itself
    for (int i = 0; i < numParticles; ++i) {
        delete particles[i];
    }
    delete[] particles;
};
const Particle& PSO::run(const Function& func) {
    Particle* gBest = getBestParticle(func);
    // Update all particles using the best particle found
    for (int i = 0; i < numParticles; ++i) {
        particles[i]->updateParticle(*gBest);
    }

    return *gBest;
};
Particle** PSO::run(int numIterations, const Function& func) {
    Particle** bestParticles = new Particle*[numIterations];

    for (int i = 0; i < numIterations; ++i) {
        const Particle& bestParticle = run(func);
        bestParticles[i] = new Particle(bestParticle);
    }

    return bestParticles;
};
Particle* PSO::getBestParticle(const Function& func) const {
    if (numParticles == 0) {
        return NULL;
    }

    Particle* bestParticle = particles[0];
    double bestValue = bestParticle->evaluate(func);

    for (int i = 1; i < numParticles; ++i) {
        double currentValue = particles[i]->evaluate(func);
        if (currentValue < bestValue) {
            bestParticle = particles[i];
            bestValue = currentValue;
        }
    }

    return bestParticle;
};
Particle** PSO::getParticles() const {
    return particles;
};
int PSO::getNumberOfParticles() const {
    return numParticles;
};
Particle* PSO::getParticle(int pos) const {
    if (pos < 0 || pos >= numParticles) {
        return NULL;
    }
    return particles[pos];
};
Particle* PSO::getParticle(const Vector& position) const {
    for (int i = 0; i < numParticles; ++i) {
        if (particles[i]->getPosition().equal(position)) {
            return particles[i];
        }
    }
    return NULL;
};
int PSO::addParticle(const Particle& nParticle) {
    Particle** newParticles = new Particle*[numParticles + 1];
    for (int i = 0; i < numParticles; ++i) {
        newParticles[i] = particles[i];
    }
    newParticles[numParticles] = new Particle(nParticle);
    numParticles++;
    delete[] particles;
    particles = newParticles;
    return numParticles - 1;
};
bool PSO::removeParticle(const Particle& particle) {
    int countRemoved = 0;
    for (int i = 0; i < numParticles; ++i) {
        if (particles[i]->equal(particle)) {
            delete particles[i];
            countRemoved++;
        } else if (countRemoved > 0) {
            particles[i - countRemoved] = particles[i];
        }
    }
    if (countRemoved > 0) {
        numParticles -= countRemoved;
        Particle** newParticles = new Particle*[numParticles];
        for (int i = 0; i < numParticles; ++i) {
            newParticles[i] = particles[i];
        }
        delete[] particles;
        particles = newParticles;
        return true;
    }
    return false;
};
bool PSO::removeParticle(const Vector& position) {
    int countRemoved = 0;
    for (int i = 0; i < numParticles; ++i) {
        if (particles[i]->getPosition().equal(position)) {
            delete particles[i];
            countRemoved++;
        } else if (countRemoved > 0) {
            particles[i - countRemoved] = particles[i];
        }
    }
    if (countRemoved > 0) {
        numParticles -= countRemoved;
        Particle** newParticles = new Particle*[numParticles];
        for (int i = 0; i < numParticles; ++i) {
            newParticles[i] = particles[i];
        }
        delete[] particles;
        particles = newParticles;
        return true;
    }
    return false;
};
bool PSO::removeParticle(int pos) {
    if (pos < 0 || pos >= numParticles) {
        return false;
    }
    delete particles[pos];
    for (int i = pos; i < numParticles - 1; ++i) {
        particles[i] = particles[i + 1];
    }
    numParticles--;
    Particle** newParticles = new Particle*[numParticles];
    for (int i = 0; i < numParticles; ++i) {
        newParticles[i] = particles[i];
    }
    delete[] particles;
    particles = newParticles;
    return true;
};
void PSO::setMaxV(double v) {
    for (int i = 0; i < numParticles; ++i) {
        particles[i]->setVMax(v);
    }
};
