#include "Vector.h"
#include <sstream>
#include <cmath> // for floor function

Vector::Vector(std::string array) {
    // Remove brackets
    array.erase(0, 1); // remove '['
    array.erase(array.size() - 1); // remove ']'

    // Initialize size and allocate memory
    size = 1;
    for (int i = 0; i < array.size(); i++) {
    if (array[i] == ',') {
        size++;
    }
}

    this->array = new double[size];

    // Parse the string to populate the array
    std::stringstream popArray(array);
    std::string componentArray;
    int index = 0;
    while (std::getline(popArray, componentArray, ',')) {
        this->array[index++] = fromStringToDouble(componentArray);
    }
};
Vector::Vector(const Vector& other) {
    size = other.size;
    array = new double[size];
    for (int i = 0; i < size; i++) {
        array[i] = other.array[i];
    }
};
Vector::Vector(const double* array, int size) {
    if (size <= 0 || array == NULL) {
        this->array = NULL;
        this->size = 0;
    } else {
        this->size = size;
        this->array = new double[size];
        for (int i = 0; i < size; i++) {
            this->array[i] = array[i];
        }
    }
};
Vector::~Vector() {
    delete[] array;
};
double* Vector::getArray() const {
    return array;
};
int Vector::getSize() const {
    return size;
};
double Vector::fromStringToDouble(std::string v) {
    std::stringstream sTd(v);
    double result;
    sTd >> result;
    return result;
};
std::string Vector::fromDoubleToString(double v) {
    std::stringstream dTs;
    if (v == floor(v)) { // check if the double is an integer
        dTs << v << ".0"; // manually add ".0" to integer
    } else {
        dTs << v;
    }
    return dTs.str();
};
const std::string Vector::toString() const {
    std::stringstream tStr;
    tStr << "[";
    for (int i = 0; i < size; i++) {
        tStr << fromDoubleToString(array[i]);
        if (i < size - 1) {
            tStr << " , ";
        }
    }
    tStr << "]";
    return tStr.str();
};
double Vector::get(int index) const {
    if (index < 0 || index >= size) {
        return 0.0;
    }
    return array[index];
};
bool Vector::equal(const Vector& other) const {
    if (size != other.size) {
        return false;
    }
    for (int i = 0; i < size; i++) {
        if (array[i] != other.array[i]) {
            return false;
        }
    }
    return true;
};

