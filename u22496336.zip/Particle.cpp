#include "Particle.h"
#include "Function.h"
#include "Vector.h"
#include <cmath>
#include <sstream>

Particle::Particle(std::string line) {
    // Initialize vMax to 1 and pBest to NULL
    vMax = 1.0;
    pBest = NULL;

    // Parse the input string
    std::istringstream inputString(line);
    std::string part;
    getline(inputString, part, '|'); // Skip the first '|'
    getline(inputString, part, '|'); // Get position components
    position = new Vector(part);
    getline(inputString, part, '|'); // Get velocity components
    velocity = new Vector(part);
    getline(inputString, part, '|'); // Get w
    w = Vector::fromStringToDouble(part);
    getline(inputString, part, '|'); // Get c1
    c1 = Vector::fromStringToDouble(part);
    getline(inputString, part, '|'); // Get c2
    c2 = Vector::fromStringToDouble(part);
};
Particle::Particle(const Particle &other) {
    // Deep copy of the position, velocity, and pBest vectors
    position = new Vector(*other.position);
    velocity = new Vector(*other.velocity);
    pBest = other.pBest ? new Vector(*other.pBest) : NULL;

    // Copy other member variables
    w = other.w;
    c1 = other.c1;
    c2 = other.c2;
    vMax = other.vMax;
};
Particle::~Particle() {
    // Deallocate dynamic memory
    delete position;
    delete velocity;
    if (pBest) {
        delete pBest;
    }
};
void Particle::updateParticle(const Particle &gBest) {
    for (int i = 0; i < position->getSize(); ++i) {
        double r1 = (double)rand() / RAND_MAX;
        double r2 = (double)rand() / RAND_MAX;
        double newVelocity;

        if (pBest != NULL) {
            newVelocity = w * velocity->get(i) +
                          c1 * r1 * (pBest->get(i) - position->get(i)) +
                          c2 * r2 * (gBest.getPosition().get(i) - position->get(i));
        } else {
            newVelocity = w * velocity->get(i) +
                          c2 * r2 * (gBest.getPosition().get(i) - position->get(i));
        }

        // Apply velocity clamping
        if (newVelocity > vMax) {
            newVelocity = vMax;
        } else if (newVelocity < -vMax) {
            newVelocity = -vMax;
        }

        // Update velocity
        velocity->getArray()[i] = newVelocity;

        // Update position
        position->getArray()[i] += newVelocity;
    }
};
const Vector& Particle::getPosition() const {
    return *position;
};
const Vector& Particle::getVelocity() const {
    return *velocity;
};
const Vector* Particle::getPBest() const {
    return pBest;
};
void Particle::setVMax(double vMax) {
    this->vMax = fabs(vMax); // Set vMax to the absolute value of the passed-in value
};
double Particle::evaluate(const Function& function) {
    double currentValue = function.evaluate(*position);

    if (pBest != NULL) {
        double pBestValue = function.evaluate(*pBest);
        if (currentValue < pBestValue) {
            delete pBest;
            pBest = new Vector(*position);
        }
    } else {
        pBest = new Vector(*position);
    }

    return currentValue;
};
bool Particle::equal(const Particle& other) const {
    return position->equal(*other.position) && velocity->equal(*other.velocity);
};
double Particle::getW() const {
    return w;
};
double Particle::getC1() const {
    return c1;
};
double Particle::getC2() const {
    return c2;
};
double Particle::getVMax() const {
    return vMax;
};
