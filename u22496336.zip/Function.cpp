#include "Function.h"
#include <cmath>

double Function::evaluate(const Vector& inputs) const
{
    if (inputs.getSize() < 2) {
        // Handle cases where the vector doesn't have at least 2 components
        return 0.0;
    }
    double x = inputs.get(0);
    double y = inputs.get(1);

    return 0.1*pow(x,2) + 3*pow(y,2);
};